#!/bin/bash
# ==============================================================================
# Script de Preparación Inicial - NODO COORDINADOR IA (Raspberry Pi 5)
# ==============================================================================
# Ejecutar UNA SOLA VEZ al configurar la Pi5 por primera vez.

# Nombres canónicos que espera config.yml
CERT_NAME="Pi5-dani.cert.pem"
KEY_NAME="Pi5-dani.private.key"
CA_NAME="root-CA.crt"

echo "[INFO] Preparando entorno seguro para la Raspberry Pi 5 (Coordinador IA)..."

# Crear carpeta para certificados AWS IoT si no existe
if [ ! -d "./certificados" ]; then
    mkdir -p ./certificados
    chmod 700 ./certificados
    echo "[SUCCESS] Carpeta 'certificados/' creada."
    echo "   -> Mueve aquí los ficheros de AWS (.pem, .key, root-CA.crt)."
else
    echo "[INFO] La carpeta 'certificados/' ya existe."
fi

# ==============================================================================
# Auto-detección y renombrado de certificados AWS IoT
# Detecta por nombre/extensión qué fichero es cada cosa y los normaliza.
# Funciona con cualquier nombre que descargue AWS (ej: abc123-certificate.pem.crt)
# ==============================================================================
normalize_certificates() {
    local dir="./certificados"
    local encontrado_cert=""
    local encontrado_key=""
    local encontrado_ca=""

    # Buscar entre todos los ficheros de la carpeta
    for f in "$dir"/*; do
        [ -f "$f" ] || continue
        local nombre
        nombre=$(basename "$f")
        local nombre_lower
        nombre_lower=$(echo "$nombre" | tr '[:upper:]' '[:lower:]')

        # Ya tiene el nombre correcto → saltar
        if [ "$nombre" = "$CERT_NAME" ] || [ "$nombre" = "$KEY_NAME" ] || [ "$nombre" = "$CA_NAME" ]; then
            continue
        fi

        # Root CA: Amazon Root CA 1 tiene prioridad sobre Root CA 3
        # (los endpoints -ats de AWS usan la cadena firmada por Root CA 1)
        if echo "$nombre_lower" | grep -qE "rootca1|root.ca.1|amazonrootca1"; then
            # Root CA 1 explícita → prioridad máxima, sobreescribe cualquier CA anterior
            encontrado_ca="$f"
        elif echo "$nombre_lower" | grep -qE "root|amazon"; then
            # Otra Root CA (ej: Root CA 3) → solo usar si no hay Root CA 1
            if [ -z "$encontrado_ca" ]; then
                encontrado_ca="$f"
            fi
        # Clave PRIVADA: contiene "private" en el nombre
        # (excluimos explícitamente las claves públicas que también terminan en .key)
        elif echo "$nombre_lower" | grep -q "private"; then
            encontrado_key="$f"
        # Clave pública: contiene "public" → ignorar, AWS la descarga pero no se usa
        elif echo "$nombre_lower" | grep -q "public"; then
            : # no hacer nada con la clave pública
        # Certificado de dispositivo: .pem, .crt o .pem.crt (lo que queda)
        elif echo "$nombre_lower" | grep -qE "\.pem$|\.crt$|\.pem\.crt$|certif"; then
            encontrado_cert="$f"
        fi
    done

    local renamed=false

    if [ -n "$encontrado_ca" ] && [ ! -f "$dir/$CA_NAME" ]; then
        mv "$encontrado_ca" "$dir/$CA_NAME"
        echo "   [INFO] Root CA:    $(basename "$encontrado_ca") → $CA_NAME"
        renamed=true
    fi

    if [ -n "$encontrado_key" ] && [ ! -f "$dir/$KEY_NAME" ]; then
        mv "$encontrado_key" "$dir/$KEY_NAME"
        echo "   [INFO] Clave:      $(basename "$encontrado_key") → $KEY_NAME"
        renamed=true
    fi

    if [ -n "$encontrado_cert" ] && [ ! -f "$dir/$CERT_NAME" ]; then
        mv "$encontrado_cert" "$dir/$CERT_NAME"
        echo "   [INFO] Cert dispo: $(basename "$encontrado_cert") → $CERT_NAME"
        renamed=true
    fi

    if [ "$renamed" = true ]; then
        echo "[SUCCESS] Certificados normalizados correctamente."
    fi

    # Verificación final
    local ok=true
    for expected in "$dir/$CERT_NAME" "$dir/$KEY_NAME" "$dir/$CA_NAME"; do
        if [ ! -f "$expected" ]; then
            echo "[WARNING] Falta: $(basename "$expected")"
            ok=false
        fi
    done

    if [ "$ok" = true ]; then
        echo "[SUCCESS] Los 3 certificados están listos."
    else
        echo ""
        echo "[WARNING] Pon los certificados de AWS IoT en ./certificados/ y vuelve a ejecutar este script."
        echo "   Ficheros necesarios:"
        echo "     - Certificado del dispositivo  (.pem o .crt)"
        echo "     - Clave privada                (.key o contiene 'private')"
        echo "     - Root CA de Amazon            (contiene 'root' o 'amazon')"
    fi
}

# Solo ejecutar si hay ficheros en la carpeta (puede que ya estén bien nombrados)
if [ -n "$(ls -A ./certificados 2>/dev/null)" ]; then
    echo "[INFO] Verificando y normalizando certificados..."
    normalize_certificates
else
    echo "[WARNING] La carpeta 'certificados/' está vacía. Añade los ficheros de AWS IoT."
fi

# Crear o actualizar el archivo .env con las credenciales necesarias
if [ ! -f "./.env" ]; then
    echo ""
    echo "[INFO] Configurando credenciales del sistema..."
    echo ""

    # --- Gemini API Key ---
    read -rp "   Introduce tu GEMINI_API_KEY: " gemini_key
    if [ -z "$gemini_key" ]; then
        gemini_key="tu_clave_de_gemini_aqui"
        echo "   [WARNING] No se introdujo clave. Edita el .env manualmente mas tarde."
    fi

    # --- Dashboard credentials ---
    echo ""
    echo "   [INFO] Configura las credenciales del Dashboard Web (Flask-HTTPAuth)."
    read -rp "   Usuario para el Dashboard [admin]: " dash_user
    dash_user=${dash_user:-admin}

    while true; do
        read -rsp "   Contrasena para el Dashboard: " dash_pass
        echo ""
        if [ -z "$dash_pass" ]; then
            echo "   [ERROR] La contrasena no puede estar vacia. Intentalo de nuevo."
        else
            read -rsp "   Confirma la contrasena: " dash_pass_confirm
            echo ""
            if [ "$dash_pass" = "$dash_pass_confirm" ]; then
                break
            else
                echo "   [ERROR] Las contrasenas no coinciden. Intentalo de nuevo."
            fi
        fi
    done

    # Escribir el archivo .env con permisos restrictivos
    cat > ./.env << EOF
GEMINI_API_KEY=${gemini_key}
DASHBOARD_USER=${dash_user}
DASHBOARD_PASSWORD=${dash_pass}
EOF
    chmod 600 ./.env
    echo ""
    echo "[SUCCESS] Archivo '.env' creado con credenciales seguras."
    echo "   -> Usuario del dashboard: ${dash_user}"
    echo "   -> Para modificar: nano .env"
else
    echo "[INFO] El archivo '.env' ya existe."
    # Verificar que contiene las variables del dashboard
    if ! grep -q "DASHBOARD_PASSWORD" ./.env; then
        echo "[WARNING] El .env no contiene DASHBOARD_PASSWORD."
        echo "   Anade manualmente estas lineas a tu .env:"
        echo "     DASHBOARD_USER=admin"
        echo "     DASHBOARD_PASSWORD=tu_contrasena_aqui"
    fi
fi

echo ""
echo "======================================================="
echo "[SUCCESS] Entorno de la Pi5 preparado."
echo "Próximos pasos:"
echo "  1) Si falta algún cert, colócalo en './certificados/' y re-ejecuta este script."
echo "  2) Edita tu clave API con: nano .env"
echo "  3) Ejecuta './arrancar_soc.sh' para lanzar el sistema."
echo "======================================================="
