#!/bin/bash
# ==============================================================================
# Script de arranque interno del contenedor Docker (Pi5 - Coordinador IA)
# NO ejecutar directamente en el host — es el CMD del Dockerfile.
# ==============================================================================

RETRY_DELAY=15  # segundos entre reintentos del coordinador

# --- Dashboard Flask (proceso permanente en background) ---
echo "[INFO] Iniciando Dashboard Web SOC..."
python3 src/dashboard_soc.py &
DASHBOARD_PID=$!

# Verificar que el dashboard arrancó
sleep 2
if ! kill -0 "$DASHBOARD_PID" 2>/dev/null; then
    echo "[ERROR] El dashboard no pudo arrancar. Revisa los logs."
    exit 1
fi
echo "[SUCCESS] Dashboard activo (PID $DASHBOARD_PID) en puerto 5000."

# --- Coordinador IA (con reintentos automáticos) ---
echo "[INFO] Iniciando Agente Coordinador SOC..."
while true; do
    python3 src/main_coordinator.py
    EXIT_CODE=$?

    # Si el dashboard murió, salir del contenedor para que Docker lo reinicie
    if ! kill -0 "$DASHBOARD_PID" 2>/dev/null; then
        echo "[ERROR] El dashboard ha muerto inesperadamente. Reiniciando contenedor..."
        exit 1
    fi

    echo ""
    echo "[WARNING] Coordinador detenido (código: $EXIT_CODE). Reintentando en ${RETRY_DELAY}s..."
    echo "   (El dashboard sigue activo en http://0.0.0.0:5000)"
    sleep "$RETRY_DELAY"
    echo "[INFO] Relanzando coordinador..."
done
