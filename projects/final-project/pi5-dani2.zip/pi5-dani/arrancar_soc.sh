#!/bin/bash
# ==============================================================================
# Script de Arranque GitOps - NODO COORDINADOR IA (Raspberry Pi 5)
# ==============================================================================
# Coloca este script en la Raspberry Pi 5 y ejecútalo para arrancar el SOC.
# Descargará automáticamente la última versión del código desde GitHub.

REPO_URL="https://github.com/LopedeVega22/Sentinel-IT.git"
CLONE_DIR=".soc_engine_src"

echo "[INFO] Iniciando Motor SOC - COORDINADOR IA (Pi5)..."

# 1. Verificar e instalar prerrequisitos automáticamente
NEEDS_RESTART=false

if ! command -v git &> /dev/null; then
    echo "[INFO] Git no encontrado. Instalando..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq git
    if ! command -v git &> /dev/null; then
        echo "[ERROR] No se pudo instalar Git."
        exit 1
    fi
    echo "[SUCCESS] Git instalado correctamente."
fi

if ! command -v docker &> /dev/null; then
    echo "[INFO] Docker no encontrado. Instalando (puede tardar unos minutos)..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq ca-certificates curl
    curl -fsSL https://get.docker.com | sudo sh
    if ! command -v docker &> /dev/null; then
        echo "[ERROR] No se pudo instalar Docker."
        exit 1
    fi
    # Añadir usuario actual al grupo docker para no necesitar sudo
    sudo usermod -aG docker "$USER"
    NEEDS_RESTART=true
    echo "[SUCCESS] Docker instalado correctamente."
fi

# Verificar que docker compose está disponible
if ! docker compose version &> /dev/null; then
    echo "[INFO] Plugin 'docker compose' no encontrado. Instalando..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq docker-compose-plugin
    if ! docker compose version &> /dev/null; then
        echo "[ERROR] No se pudo instalar docker-compose-plugin."
        exit 1
    fi
    echo "[SUCCESS] Docker Compose instalado correctamente."
fi

# Si Docker se acaba de instalar, el grupo aún no está activo en esta sesión
if [ "$NEEDS_RESTART" = true ]; then
    echo ""
    echo "[WARNING] Docker se ha instalado por primera vez."
    echo "   Es necesario reiniciar la sesión para aplicar permisos."
    echo "   Ejecuta: newgrp docker && ./arrancar_soc.sh"
    echo "   O cierra sesión, vuelve a entrar, y ejecuta de nuevo este script."
    exit 0
fi

if [ ! -d "./certificados" ] || [ ! -f "./.env" ]; then
    echo "[ERROR] Faltan credenciales. Ejecuta primero './setup_credenciales.sh'."
    exit 1
fi

# 2. Detectar modo de ejecución: local o GitOps
if [ -f "./docker-compose.yml" ]; then
    # ── MODO LOCAL ─────────────────────────────────────────────────────────────
    # El código ya está presente en este directorio. Se omite el clonado.
    echo "[INFO] Modo local detectado: usando el código del directorio actual."
    echo "[INFO] Levantando contenedor..."
    docker compose up -d --build

else
    # ── MODO GITOPS ────────────────────────────────────────────────────────────
    # Se descarga la última versión desde GitHub.
    echo "[INFO] Sincronizando código desde GitHub..."
    rm -rf "$CLONE_DIR"
    if ! git clone -q "$REPO_URL" "$CLONE_DIR"; then
        echo "[ERROR] Fallo al clonar el repositorio. Verifica la URL o el acceso a red."
        exit 1
    fi

    # Verificar que el repo contiene la carpeta pi5-dani/ esperada
    if [ ! -d "$CLONE_DIR/pi5-dani" ]; then
        echo ""
        echo "[ERROR] El repositorio clonado no contiene la carpeta 'pi5-dani/'."
        echo "   El código aún no ha sido enviado a GitHub desde tu PC de desarrollo."
        echo ""
        echo "   Desde tu PC, ejecuta:"
        echo "     cd <ruta-del-proyecto-TFG>"
        echo "     git add ."
        echo "     git commit -m 'Deploy SOC Pi5'"
        echo "     git push"
        echo ""
        rm -rf "$CLONE_DIR"
        exit 1
    fi

    # Inyectar credenciales en la copia de trabajo
    echo "[INFO] Inyectando credenciales seguras..."
    cp -r ./certificados "$CLONE_DIR/pi5-dani/certificados"
    cp ./.env "$CLONE_DIR/pi5-dani/.env"

    # Levantar el contenedor desde la subcarpeta pi5-dani/
    cd "$CLONE_DIR/pi5-dani" || exit 1
    docker compose up -d --build
fi

echo ""
echo "======================================================="
echo "[SUCCESS] COORDINADOR IA (PI5) OPERATIVO!"
echo "======================================================="
echo "» Dashboard: http://localhost:5000"
echo "» Auth:      Credenciales configuradas en .env"
echo "» Para actualizar: git push en tu PC y reinicia este script."
echo "======================================================="
