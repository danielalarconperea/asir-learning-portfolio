# Guía de Referencia Técnica: SOC Autónomo (Sentinel-IT)

Esta guía ha sido diseñada para servir de base técnica en la redacción de tu memoria de TFG. Contiene la explicación de la arquitectura, decisiones de diseño y fragmentos de código clave del sistema SOC implementado.

---

## 1. Arquitectura General del Sistema

El proyecto sigue una arquitectura de **Edge Computing Distribuido** dividida en dos roles principales:

* **Sensores (Raspberry Pi 4):** Nódos periféricos que ejecutan servicios reales (SSH, Web, etc.). Monitorizan sus propios logs y los envían en tiempo real a la nube.
* **Coordinador IA (Raspberry Pi 5):** El "cerebro" del sistema. Escucha los eventos que llegan de todos los sensores, los analiza mediante Inteligencia Artificial (Google Gemini) y decide si debe ejecutar una acción de mitigación (bloqueo de IP).

### Ventajas de este modelo:

1. **Escalabilidad:** Se pueden añadir N sensores sin modificar el código del coordinador.
2. **Aislamiento:** Si un sensor es comprometido, el coordinador permanece seguro.
3. **Eficiencia:** El procesamiento pesado de IA se centraliza en el nodo más potente.

---

## 2. Infraestructura AWS IoT Core y MQTT

La comunicación entre nodos se realiza mediante el servicio **AWS IoT Core**, utilizando el protocolo **MQTT (Message Queuing Telemetry Transport)** bajo el estándar **mTLS (Mutual TLS)**.

### Seguridad mTLS

A diferencia del HTTPS estándar, en este proyecto cada nodo (Pi 4 y Pi 5) tiene su propio **Certificado X.509**, **Clave Privada** y una **CA Raíz**.

* El servidor valida al cliente.
* El cliente valida al servidor.
  Esto garantiza que nadie pueda inyectar logs falsos ni interceptar las órdenes de bloqueo.

### Protocolo MQTT

Se han definido dos canales (topics) principales:

* `soc/logs`: Los sensores publican sus eventos aquí.
* `soc/actions/+`: El coordinador publica órdenes de bloqueo dirigidas a un sensor específico (usando un *wildcard*).

---

## 3. El Agente SOC (Google ADK)

Se ha utilizado el framework **Google ADK (Agent Development Kit)** para orquestar la lógica de seguridad.

### Lógica de Análisis (Chain of Thought)

El agente no solo clasifica; utiliza **Chain of Thought (Cadena de Pensamiento)**. Antes de actuar, el modelo debe "razonar" internamente el porqué de su decisión. Esto reduce falsos positivos y hace que el sistema sea auditable.

### Código Clave: Configuración del Agente (`soc_agent.py`)

```python
soc_agent = LlmAgent(
    name="SOC_Root_Agent",
    model="gemini-2.5-flash", 
    instruction="""
    Eres un analista de SOC Nivel 1.
  
    ### PROTOCOLO:
    1. Si es tráfico BENIGNO: No hagas nada.
    2. Si es ATAQUE CONFIRMADO (Brute force, SQLi, etc.): 
       - Llama a 'register_alert' para la base de datos.
       - Llama a 'block_ip' para mitigar el ataque.
     
    ### TÉCNICA:
    - Debes extraer la [source_ip] de cualquier formato de log (Nginx, Syslog, etc).
    - Usa 'Chain of Thought': razona paso a paso antes de llamar a las herramientas.
    """
)
```

**Explicación:**

* **Gemini 1.5 Flash:** Elegido por su baja latencia y bajo coste para procesar logs en tiempo real.
* **register_alert / block_ip:** Son "herramientas" (Python functions) que el modelo decide usar si detecta una amenaza.

---

## 4. Optimización: Sistema Dual-Trigger Microbatch

Este es uno de los componentes más avanzados del proyecto, diseñado para evitar el colapso de la API y reducir costes.

### El Problema del "Attack Storm"

En un ataque de fuerza bruta, un sensor puede enviar 100 logs por segundo. Llamar a la IA por cada log individualmente agotaría la cuota de Google Gemini en segundos.

### La Solución: Microbatching

El coordinador acumula los logs en una cola y los envía al agente en "lotes" (batches) cuando se cumple una de estas dos condiciones (**Dual-Trigger**):

1. **Tamaño:** La cola alcanza 10 logs.
2. **Tiempo:** Pasan 15 segundos desde el último análisis.

### Código Clave: Lógica de la Cola (`main_coordinator.py`)

```python
class LogBatchQueue:
    def add(self, device, raw_log):
        with self._lock: # Protección contra acceso múltiple (Thread-safe)
            self._queue.append({"device": device, "raw_log": raw_log})
            # Trigger por tamaño: ¿llegamos al máximo?
            return len(self._queue) >= self._max_size

    def flush(self):
        with self._lock:
            batch = list(self._queue) # Copia los logs
            self._queue.clear()       # Vacía la cola
            self._last_flush = time.time() # Reinicia el cronómetro
            return batch
```

**Explicación línea a línea:**

* `threading.Lock()`: Vital porque los mensajes MQTT llegan en hilos diferentes. Evita que los datos se corrompan.
* `len(self._queue) >= self._max_size`: Si hay ráfaga de ataques, el sistema responde de inmediato sin esperar al timer.
* `flush()`: Extrae los datos de forma atómica para procesarlos.

---

## 5. Dashboard SOC v2 (Estética y UX)

El dashboard ha sido rediseñado con una estética **"Matte Clean"** enfocada en la legibilidad profesional.

### Innovaciones Técnicas:

* **AJAX Auto-Refresh:** El servidor Flask expone un endpoint `/api/data`. El cliente (navegador) solicita datos cada 5 segundos mediante JavaScript (`fetch`). Esto elimina el parpadeo de recarga de página.
* **Threat Level Heuristic:** El "Nivel de Amenaza" se calcula dinámicamente mediante una fórmula ponderada:
  `Nivel = ((Críticos * 3) + (Altos * 2) + Medios) / Total * 25`
* **Logs Expandibles:** Los logs crudos (que pueden ser muy largos) se muestran truncados. Un click permite expandirlos sin cambiar de vista, facilitando el análisis rápido.

### Seguridad del Dashboard

Se implementó **HTTP Basic Auth** integrado con variables de entorno:

```python
@auth.verify_password
def verify_password(username, password):
    # Compara el hash de la contraseña, nunca el texto plano
    if username == os.getenv('USER') and check_password_hash(HASH, password):
        return username
```

---

## 6. Proceso de Profesionalización del Código

Un punto clave para tu memoria es el proceso de refabricación (*Refactoring*):

1. **Estandarización de Logs:** Se eliminaron emojis y se sustituyeron por tags estándar `[INFO]`, `[ERROR]`, `[BATCH]`.
2. **Internacionalización:** Todo el código (variables, funciones, comentarios) se tradujo al Inglés para seguir las guías de estilo profesionales de desarrollo de software.
3. **Abstracción de Vectores:** El sistema ya no busca solo "SSH". Ahora el campo `attack_vector` es dinámico, permitiendo detectar ataques HTTP, SQL, o de cualquier protocolo sin cambiar la base de datos.
4. **Limpieza de Esquema:** Se migró de nombres de tablas en español (`base_datos.py`) a una estructura más limpia (`database.py`) con soporte para WAL (Write-Ahead Logging) para evitar bloqueos de base de datos en lecturas concurrentes.

---

## 7. Sugerencias de Capturas para la Memoria

Para que tu Word quede visualmente impactante, te recomiendo incluir estas capturas:

1. **Dashboard General:** Una toma a pantalla completa del nuevo Dashboard con el anillo de "Threat Level" en rojo y el gráfico de barras de vectores.
2. **Terminal del Coordinador:** Una captura de la Pi 5 mostrando los mensajes `[BATCH] Trigger: SIZE (queue=10)` junto a las respuestas del agente. Esto demuestra que la lógica de microbatching funciona.
3. **AWS IoT Monitor:** Una captura del panel de AWS donde se vean los mensajes MQTT llegando al topic `soc/logs`.
4. **Docker Desktop / Portainer:** Una captura de los contenedores `pi5-soc-coordinator` funcionando.
5. **Expandible de Logs:** Captura del dashboard con un log de ataque expandido (se verá la cadena de razonamiento de la IA).

---

Extra (apuntes en sucio):

Dual-Trigger Batch	Proteger la cuota de la API de Gemini ante ataques masivos	Flask-HTTPAuth	Seguridad de acceso al dashboard
